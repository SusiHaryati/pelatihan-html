#include<conio.h>
#include<stdio.h>
#include<windows.h>

//No.1
// struct Toko
// {
//    int harga;
//    char *barang;
// }Tulis[50];

// void main()
// {
//     int total,batas;

//     printf("Jumlah barang yang akan dibeli : "); scanf("%d",&batas);

//     for(int a=0; a<batas; a++)
//     {
//         printf("\nBarang ke- %d\n",a+1);
//         printf("Barang : "); scanf("%s",&Tulis[a].barang);
//         printf("Harga : "); scanf("%d",&Tulis[a].harga);
//         total+=Tulis[a].harga;
//     }

//     printf("Total Bayar : %d",total);
   
//     getch();
// }


//No.2
// struct Nilai
// {
//    char *nama;
//    int nilai_math;
//    int nilai_english;
// };

// void main()
// {
//     struct Nilai Siswa1, Siswa2;

//     Siswa1.nama="Susi Haryati";
//     Siswa2.nama="Khalisyah";
   
//     printf("\n>>>>> NILAI SISWA <<<<<\n");
//     printf("\nNama Siswa : %s",Siswa1.nama);
//     printf("\nNilai Matematika : "); scanf("%d",&Siswa1.nilai_math);
//     printf("Nilai Inggris : "); scanf("%d",&Siswa1.nilai_english);

//     printf("\n\nNama Siswa : %s",Siswa2.nama);
//     printf("\nNilai Matematika : "); scanf("%d",&Siswa2.nilai_math);
//     printf("Nilai Inggris : "); scanf("%d",&Siswa2.nilai_english);

    
//     getch();
// }


//NO.3
// struct Tanggal{
//     int hari;
//     int minggu;
//     int bulan;
//     int tahun;    
// };

// void main()
// {
//     struct Tanggal Hitung_hari;
//     int total;

//     printf("Masukan Hari : "); scanf("%d",&Hitung_hari.hari);
//     printf("Masukan Minggu : "); scanf("%d",&Hitung_hari.minggu);
//     printf("Masukan Bulan : "); scanf("%d",&Hitung_hari.bulan);

//     Hitung_hari.hari=(Hitung_hari.bulan*30)+(Hitung_hari.minggu*7)+Hitung_hari.hari;
//     total = Hitung_hari.hari;

//     Hitung_hari.tahun= Hitung_hari.hari/365;
//     Hitung_hari.bulan= Hitung_hari.hari%365/30;
//     Hitung_hari.minggu=Hitung_hari.hari%365%30/7;
//     Hitung_hari.hari=Hitung_hari.hari%30%7/1;

//     printf("\n%d Tahun %d Bulan %d Minggu %d Hari",Hitung_hari.tahun,Hitung_hari.bulan,Hitung_hari.minggu,Hitung_hari.hari);

//     printf("\nTotal Hari %d",total);

//     getch();
// }


//NO.4
// struct Sepatu
// {
//     char nama[50];
//     char merek[50];
//     int ukuran;
// };

// void main()
// {
//     struct Sepatu Sepatu1, Sepatu2;
    
//     strcpy(Sepatu1.nama,"Susi Haryati");
//     strcpy(Sepatu1.merek,"ADIDAS");
//     Sepatu1.ukuran=38;

//     strcpy(Sepatu2.nama,"Fadilla");
//     strcpy(Sepatu2.merek,"NIKE");
//     Sepatu2.ukuran=37;

//     printf(">>>>> KEPEMILIKAN SEPATU <<<<<");

//     printf("\nPemilik : %s",strupr(Sepatu1.nama));
//     printf("\nMerek   : %s",strlwr(Sepatu1.merek));
//     printf("\nUkuran  : %d",Sepatu1.ukuran);

//     printf("\nPemilik : %s",strupr(Sepatu2.nama));
//     printf("\nMerek   : %s",strlwr(Sepatu2.merek));
//     printf("\nUkuran  : %d",Sepatu2.ukuran);

//     getch();
// }

//NO.5
struct Mahasiswa
{
    char nama[30];
    char prodi[50];
    struct NamaMapel
    {
       char matkul[25];
       int nilai;
    }Nilmatkul[10];
    
}Mhs[10];

void main()
{
    int data,tamp=0,rata;

    printf("Masukan Jumlah Data : "); scanf("%d",&data);
    getchar();
    for(int a=0; a<data; a++)
    {
        printf("Nama Mahasiswa : "); gets(Mhs[a].nama);
        printf("Program Studi  : "); gets(Mhs[a].prodi);
        for(int b=0; b<3; b++)
        {
            
            printf("Mata Kuliah : "); gets(Mhs[b].Nilmatkul[b].matkul);
            printf("Nilai Matkul: "); scanf("%d",&Mhs[b].Nilmatkul[b].nilai);
            getchar();
            tamp+=Mhs[b].Nilmatkul[b].nilai;
        }
        rata = tamp/3;
        printf("Nilai Rata rata : %d",rata);
        tamp=0;
        printf("\n\n");
    }

    getch();
}